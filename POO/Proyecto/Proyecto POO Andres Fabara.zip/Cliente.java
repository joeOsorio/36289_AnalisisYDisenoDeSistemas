//Clase Cliente que tiene los atributos y metodos para el nombre, numero Telefono
//En esta clase tambien se Asocia la clase Fecha y Composicion con la clase Ticket
//Hecho por andres.fabara@uabc.edu.mx
public class Cliente{
    //Atributos
    private String nombre;
    private double numTel;
    private Fecha fecha;
    private Ticket ticket;
    //Constructor
    public Cliente(String nombre, double numTel, int numOrden, int metPago, int servicio, Ticket ticket){
        this.nombre = nombre;
        this.numTel = numTel;
        this.ticket = new Ticket(numOrden, metPago, servicio, fecha);
    }
    //Metodos set y get para el nombre, el numeroTelefono y el ticket del Cliente
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public String getNombre(){
        return nombre;
    }
    public void setNumTel(double numTel){
        this.numTel = numTel;
    }
    public double getNumTel(){
        return numTel;
    }
    public void setTicket(Ticket ticket){
        this.ticket = ticket;
    }
    public Ticket getTicket(){
        return ticket;
    }
    //Metodo toString de la clase
    public String toString(){
        return "\nCon nombre: "+nombre+"\nNumero de Telefono: "+numTel+" "+ticket.toString();
    }
    
}