//Clase Fecha que tiene atributos y metodos con el dia, mes y anio
//Hecho por andres.fabara@uabc.edu.mx
public class Fecha {
    //Atributos
    private int dia;
    private int mes;
    private int anio;
    //Constructor
    public Fecha(int dia, int mes, int anio) {
        this.dia=dia;
        this.mes=mes;
        this.anio=anio;
    }
    //Metodos set y get para el dia, mes y anio
    public void setDia(int dia){
        this.dia=dia;
    }
    public void setMes(int mes){
        this.mes=mes;
    }
    public void setAnio(int anio){
        this.anio=anio;
    }
    public int getDia(){
        return dia;
    }
    public int getMes(){
        return mes;
    }
    public int getAnio(){
        return anio;
    }
    //Metodo toString de la Clase
    public String toString(){
        return dia + "/" +mes +"/"+ anio;
    }
}