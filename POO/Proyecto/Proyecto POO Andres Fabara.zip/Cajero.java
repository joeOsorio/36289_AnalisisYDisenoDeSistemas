//Hecho por andres.fabara@uabc.edu.mx
//Se importan las bibliotecas de ArrayList y List
import java.util.ArrayList;
import java.util.List;
//Clase Cajero que hereda los atributos y metodos de la clase Empleado
//En esta clase tambien tiene atributo salario y Lista de los Clientes
public class Cajero extends Empleado{
    private List<Cliente> clientes;
    private double salario;
    //Constructor
    public Cajero(String nombre, double numTel, String nSS, double salario){
        super(nombre, numTel, nSS);
        if(salario < 0.0)
        throw new IllegalArgumentException("El salario debe ser mayor a 0.0");
        this.salario = salario;
        this.clientes = new ArrayList <>();
    }
    //Metodos set y get para el Salario del Cajero
    public void setSalario(double salario){
        if(salario < 0)
        throw new IllegalArgumentException("El salario debe ser mayor a 0.0");
        this.salario = salario;
    }
    public double getSalario(){
        return salario;
    }
    //Metodo para agregar clientes a la Lista
    public void agregarCliente(Cliente cliente){
        clientes.add(cliente);
        System.out.println("Cliente añadido a la lista!");
    }
    //Metodo para eliminar clientes de la lista
    public void eliminarCliente(String nombre){
        boolean encontrado = false;
        for(int i = 0; i<clientes.size(); i++){
            if(clientes.get(i).getNombre().equalsIgnoreCase(nombre)){
                System.out.println("Cliente eliminado: "+clientes.get(i).getNombre());
                clientes.remove(i);
                encontrado = true;
                break;
            }
        }
        if(!encontrado){
            System.out.println("No se encontro el Cliente con nombre: "+nombre);
        }
    }
    //Metodo para mostrar la lista de clientes
    public void ListaClientes(){
        if(clientes.isEmpty()){
            System.out.println("En la lista de clientes no hay nadie...");
        }else{
            System.out.println("\nSu lista de clientes: ");
            for(Cliente cliente : clientes){
                System.out.println(cliente);
            }
        }
    }
}