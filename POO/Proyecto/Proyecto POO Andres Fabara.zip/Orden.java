//Hecho por andres.fabara@uabc.edu.mx
//Se importan las bibliotecas de ArrayList y List
import java.util.ArrayList;
import java.util.List;
//Clase Orden que tiene los atributos y metodos para el numeroOrden, metodo pago y servicio
//En esta Clase tambien se Agrega la Clase Producto con un ArrayList realizando la Multiplicidad
public abstract class Orden{
    //Atributos y lista Productos
    protected int numOrden;
    protected int metPago, servicio;
    protected List<Producto> productos;
    //Constructor
    public Orden(int numOrden, int metPago, int servicio){
        if(numOrden < 0)
        throw new IllegalArgumentException("El numero de Orden debe ser mayor a 0");
        this.numOrden = numOrden;
        if(metPago < 1 || metPago > 2)
        throw new IllegalArgumentException("Debe ingresar un 1 o un 2...");
        this.metPago = metPago;
        if(servicio < 1 || servicio > 2)
        throw new IllegalArgumentException("Debe ingresar un 1 o un 2...");
        this.servicio = servicio;
        this.productos = new ArrayList<>();
    }
    //Metodos set y get para numeroOrden, metodoPago y servicio
    public void setNumOrden(int numOrden){
        this.numOrden = numOrden;
    }
    public int getNumOrden(){
        return numOrden;
    }
    public void setMetodoPago(int metPago){
        if(metPago < 1 || metPago > 2)
        throw new IllegalArgumentException("Debe ingresar un 1 o un 2...");
        this.metPago = metPago;
    }
    public abstract String getMetodoPago();

    public void setServicio(int servicio){
        if(servicio < 1 || servicio > 2)
        throw new IllegalArgumentException("Debe ingresar un 1 o un 2...");
        this.servicio = servicio;
    }
    public abstract String getServicio();
    //Metodo para agregar productos a la lista
    public void agregarProducto(Producto producto){
        productos.add(producto);
    }
    //Metodo para eliminar productos a la lista
    public void eliminarProducto(String nombre, int cantidad) {
        boolean encontrado = false;
        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).getNombre().equalsIgnoreCase(nombre)) {
                if (productos.get(i).getCantidad() >= cantidad) {
                    //Restar la cantidad solicitada
                    productos.get(i).setCantidad(productos.get(i).getCantidad() - cantidad);
    
                    //Si la cantidad restante es 0, eliminar el producto de la lista
                    if (productos.get(i).getCantidad() == 0) {
                        System.out.println("Producto eliminado completamente: " + productos.get(i).getNombre());
                        productos.remove(i);
                    } else {
                        System.out.println("Se eliminaron " + cantidad + " unidades de " + productos.get(i).getNombre());
                    }
                } else {
                    //Se imprime cuando se ingresa una cantidad mayor a la que hay disponible
                    System.out.println("Cantidad insuficiente para eliminar. Solo hay " + productos.get(i).getCantidad() + " unidades disponibles.");
                }
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontró el producto con nombre: " + nombre);
        }
    }
    //Metodo para mostrar la Orden imprimiendo los productos, con su precio, cantidad y el total de la Orden
    public void mostrarOrden(){
        if(productos.isEmpty()){
            System.out.println("En la Orden no hay nada...");
        }else{
            System.out.println("\nSu Orden es: ");
            for(Producto producto : productos){
                System.out.println(producto);
            }
            double total = 0.0;
            for(Producto producto : productos){
                total += producto.getPrecio() * producto.getCantidad();
            }
            System.out.println("\nEL precio total de su Orden es: "+total);
        }
    }
    //Metodo para conseguir el total de la Orden
    public double getTotalOrden(){
        double total = 0.0;
        for(Producto producto : productos){
            total += producto.getPrecio() * producto.getCantidad();
        }
        return total;
    }
    public String toString(){
        return "\nSu numero de Orden: "+getNumOrden()+"\nSu metodo de pago: "+getMetodoPago()+"\nSu servicio: "+getServicio()+"\nSu total en la Orden: "+getTotalOrden();
    }
}