//Practica 3 Unidad 1
//Este programa es para un Telefono con sus variables y metodos sets y gets
//Hecho por Andres Fabara andres.fabara@uabc.edu.mx
public class CellPhone{
private String marca, modelo, procesador;
private int capacidad, RAM, pixelesCAM, numCAM;

public void setMarca(String marca){
this.marca = marca;
}
public void setModelo(String modelo){
this.modelo = modelo;
}
public void setProcesador(String procesador){
this.procesador = procesador;
}
public void setCapacidad(int capacidad){
this.capacidad = capacidad;
}
public void setRAM(int RAM){
this.RAM = RAM;
}
public void setPixelesCAM(int pixelesCAM){
this.pixelesCAM = pixelesCAM;
}
public void setNumCAM(int numCAM){
this.numCAM = numCAM;
}
public String getMarca(){
return marca;
}
public String getModelo(){
return modelo;
}
public String getProcesador(){
return procesador;
}
public int getCapacidad(){
return capacidad;
}
public int getRAM(){
return RAM;
}
public int getPixelesCAM(){
return pixelesCAM;
}
public int getNumCAM(){
return numCAM;
}
}








